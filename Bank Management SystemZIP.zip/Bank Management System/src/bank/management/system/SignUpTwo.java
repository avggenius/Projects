package bank.management.system;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignUpTwo  extends JFrame implements ActionListener
{
    
    
    JTextField pan,adhar;
    JButton next;
    JRadioButton syes,sno,eyes,eno;
    JComboBox religion,category,income,education,job;
    String formno;
    
    SignUpTwo(String formno){
     
      this.formno = formno;
      setLayout(null);

      
      setTitle("NEW ACCOUNT APPLICATION Form Page - 2");
      
      JLabel additionalDetails = new JLabel("Page 2 : Additional Details");
      additionalDetails.setFont(new Font("Raleway", Font.BOLD,22));
      additionalDetails.setBounds(290,80,500,30);
      add(additionalDetails);
      
      JLabel name = new JLabel("Religion:");
      name.setFont(new Font("Raleway", Font.BOLD,20));
      name.setBounds(100,140,100,30);
      add(name);
      String ValReligion [] = {"Select","Hindu","Sikh","Muslim","BUddhism","Other"};
      religion = new JComboBox(ValReligion);
      religion.setBounds(300,140,400,30);
      religion.setBackground(Color.WHITE);
      add(religion);
      
      
      JLabel fname = new JLabel("Category:");
      fname.setFont(new Font("Raleway", Font.BOLD,20));
      fname.setBounds(100,190,150,30);
      add(fname);
      String ValCategory[] = {"General","OBC","ST","SC","Other"};
      category = new JComboBox(ValCategory);
      category.setBounds(300,190,400,30);
      category.setBackground(Color.WHITE);
      add(category);
      
      JLabel dob = new JLabel("Income:");
      dob.setFont(new Font("Raleway", Font.BOLD,20));
      dob.setBounds(100,240,150,30);
      add(dob);
      String IncomeCategory[] = {"Null","<1,50,000","<2,50,000","<3,50,000","<400000"};
      income = new JComboBox(IncomeCategory);
      income.setBounds(300,240,400,30);
      income.setBackground(Color.WHITE);
      add(income);
      
      
      JLabel gender = new JLabel("Education");
      gender.setFont(new Font("Raleway", Font.BOLD,20));
      gender.setBounds(100,290,150,30);
      add(gender);
      JLabel email = new JLabel("Qualification:");
      email.setFont(new Font("Raleway", Font.BOLD,20));
      email.setBounds(100,330,150,30);
      add(email); 
      String educationalValues[] = {"Secondary","Senior Secondary","Graduate","Post-Graduate","PhD."};
      education = new JComboBox(educationalValues);
      education.setBounds(300,330,400,30);
      education.setBackground(Color.WHITE);
      add(education);
      
      JLabel marital = new JLabel("Occupation:");
      marital.setFont(new Font("Raleway", Font.BOLD,20));
      marital.setBounds(100,390,150,30);
      add(marital);
      String jobCategory[] = {"Student","Self-Employed","Salaried","Bussiness","Retired","Other"};
      job = new JComboBox(jobCategory);
      job.setBounds(300,390,400,30);
      job.setBackground(Color.WHITE);
      add(job);

      
      JLabel add = new JLabel("PAN-NO:");
      add.setFont(new Font("Raleway", Font.BOLD,20));
      add.setBounds(100,440,150,30);
      add(add);
      pan = new JTextField();
      pan.setFont(new Font("Raleway",Font.BOLD,14));
      pan.setBounds(300,440,400,30);
      add(pan);
      
      JLabel city = new JLabel("Adhar Number:");
      city.setFont(new Font("Raleway", Font.BOLD,20));
      city.setBounds(100,490,150,30);
      add(city);
      adhar = new JTextField();
      adhar.setFont(new Font("Raleway",Font.BOLD,14));
      adhar.setBounds(300,490,400,30);
      add(adhar);
      
      JLabel state = new JLabel("Senior Citizen:");
      state.setFont(new Font("Raleway", Font.BOLD,20));
      state.setBounds(100,540,150,30);
      add(state);
      syes = new JRadioButton("YES");
      syes.setBounds(300,540,100,30);
      syes.setBackground(Color.WHITE);
      add(syes);
      sno = new JRadioButton("NO");
      sno.setBounds(500,540,100,30);
      sno.setBackground(Color.WHITE);
      add(sno);
      
      ButtonGroup maritalgroup = new ButtonGroup();
      maritalgroup.add(syes);
      maritalgroup.add(sno);

      
      JLabel pincode = new JLabel("Existing Account:");
      pincode.setFont(new Font("Raleway", Font.BOLD,20));
      pincode.setBounds(100,590,170,30);
      add(pincode);
      eyes = new JRadioButton("YES");
      eyes.setBounds(300,590,100,30);
      eyes.setBackground(Color.WHITE);
      add(eyes);
      eno = new JRadioButton("NO");
      eno.setBounds(500,590,100,30);
      eno.setBackground(Color.WHITE);
      add(eno);
      
      ButtonGroup emaritalgroup = new ButtonGroup();
      emaritalgroup.add(eyes);
      emaritalgroup.add(eno);
      
      next = new JButton("NEXT");
      next.setBackground(Color.BLACK);
      next.setForeground(Color.WHITE);
      next.setFont(new Font ("Raleway", Font.BOLD,14));
      next.setBounds(620,660,80,30);
      next.addActionListener(this);
      add(next);
      
      getContentPane().setBackground(Color.WHITE);
        
      setSize(850,800);
      setLocation(350,10);
      setVisible(true);
    }
    
    public void actionPerformed (ActionEvent ae){
       /*String formno = ""+random;*/
       String sreligion = (String)religion.getSelectedItem();
       String scategory = (String)category.getSelectedItem();
       String sincome = (String)income.getSelectedItem();
       String seducation = (String)education.getSelectedItem();
       String soccupation = (String)job.getSelectedItem();
       String sseniorcitizen = null;
/*For Senior Citizen*/
       if(syes.isSelected())
       {
         sseniorcitizen = "syes";  
       }
       else if (sno.isSelected())
       {
           sseniorcitizen = "sno";
       }
       
/*For Existing Account*/   
       String existingaccount = null;
       if (eyes.isSelected()){
           existingaccount = "Yes";
       }
       else if (eno.isSelected())
       {
           existingaccount = "No";

       String span = pan.getText();
       String sadhar = adhar.getText();
       
       try{
           
               Conn c = new Conn();
               String query ="insert into signuptwo value('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+sadhar+"','"+sseniorcitizen+"','"+existingaccount+"')";
               c.s.executeUpdate(query);
               
               setVisible(false);
               new SignupThree(formno).setVisible(true);
           }
       catch (Exception e)
           {
           System.out.println(e);
           }
    
    
        }
    }
    
    
        public static void main(String args[]){
        new SignUpTwo("");
    }
    
}

